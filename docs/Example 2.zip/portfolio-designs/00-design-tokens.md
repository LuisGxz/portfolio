# Design Tokens — Portfolio de Luis Chiquito Vera

Tokens de identidad visual por proyecto, listos para implementar con Claude Code (Tailwind config o CSS custom properties). Escala de espaciado común: **4/8 px**. Accesibilidad objetivo: **WCAG AA** en todos.

---

## 01 · FinPulse — Banca personal

| Token | Valor |
|---|---|
| Primario (acción) | `#3DDC97` (mint 500) |
| Secundario | `#C9A961` (gold 500) |
| Fondo | `#070D17` (ink 950) · superficie `#101B2E→#0B1322` (gradiente card) |
| Texto | `#C2CFDE` (ink 100) · títulos `#FFFFFF` |
| Bordes | `#1F3251` |
| Negativo / gasto | `#F0716A` |
| Display | Space Grotesk (Google) |
| Body | Inter (Google), números tabulares |
| Radios | cards 16px (`rounded-2xl`) · botones 12px |
| Sombras | sin sombras; profundidad por gradientes y bordes |
| Tono | Confianza financiera nocturna — premium, calmado, con brillo menta y detalles dorados. |

## 02 · MediTrack — Telemedicina

| Token | Valor |
|---|---|
| Primario | `#2563EB` (trust blue) · hover `#1D4ED8` |
| Acento salud | `#059669` / fondo `#D1FAE5` |
| Estados | confirmada `#059669` · pendiente `#D97706` · cancelada `#E11D48` |
| Fondo | `#FBFCFE` · superficie blanca |
| Texto | `#0F172A` · secundario `#64748B` |
| Tipografía | Inter (única, display y body) |
| Radios | cards 16px · badges pill |
| Sombras | muy sutiles (`shadow-sm` solo en hover/activo) |
| Tono | Clínica moderna y tranquila — blanca, espaciosa, AA prioritario. |

## 03 · CivicDesk — Trámites ciudadanos

| Token | Valor |
|---|---|
| Primario | `#1E3A8A` (azul institucional) · interactivo `#1D4ED8` |
| Acentos | ámbar `#B45309`/`#FEF3C7` (alertas) · verde `#15803D`/`#DCFCE7` (aprobado) |
| Fondo | `#F9FAFB` · superficie blanca |
| Texto | `#111827` · secundario `#374151` |
| Tipografía | Public Sans (Google) — voz oficial |
| Radios | 8px (más cuadrado = institucional) |
| Sombras | mínimas; jerarquía por borde y contraste |
| Foco | outline 3px `#1D4ED8` (alto contraste) |
| Tono | Institucional pero accesible — claridad y transparencia ante todo. |

## 04 · FleetGo — Logística

| Token | Valor |
|---|---|
| Primario | `#F97316` (naranja logística) · hover `#FB923C` |
| Secundario | azul profundo `#0C1320` / `#182539` |
| OK / entregado | `#22C55E` |
| Fondo | `#0C1320` (modo nocturno por defecto) |
| Texto | `#D4DDEA` · secundario `#7E92B0` |
| Tipografía | Archivo (UI) + JetBrains Mono (IDs, ETAs) |
| Radios | botones táctiles 16px · cards 16px |
| Táctil | botones principales ≥56px de alto |
| Tono | Operativo y enérgico — alto contraste para sol y conducción nocturna. |

## 05 · ShopForge — E-commerce (café de especialidad)

| Token | Valor |
|---|---|
| Primario | `#2C1E15` (espresso) |
| Acento | `#B35F2E` (cobre) · hover `#C2703D` |
| Verde hoja | `#5F7152` (detalles orgánicos) |
| Fondo | `#FBF7F1` (crema) · superficie `#F4EDE2` |
| Texto | `#2C1E15` · secundario `#73593F` |
| Display | DM Serif Display (Google) |
| Body | Work Sans (Google) |
| Radios | imágenes 32px · botones pill |
| Sombras | ninguna; editorial plano, hover con translate |
| Tono | Editorial y aspiracional — cálido, artesanal, fotografía protagonista. |

## 06 · PulseBoard — Analítica BI

| Token | Valor |
|---|---|
| Acento datos 1 | `#22D3EE` (cian) |
| Acento datos 2 | `#A78BFA` (violeta) · positivo `#A3E635` (lima) |
| Fondo | `#0B0D10` (grafito) · widget `#101318` |
| Texto | `#CBD4E1` · secundario `#6E7C94` |
| Bordes | `#1F2530` (hover `#2B3342`) |
| Tipografía | Inter (UI) + JetBrains Mono (todos los números) |
| Radios | widgets 12px |
| Sombras | ninguna; jerarquía por capas de gris |
| Tono | Command center — denso pero elegante, los datos son el color. |

## 07 · TeamFlow — Gestión de proyectos

| Token | Valor |
|---|---|
| Acento único | `#5B5BD6` (índigo) |
| Estados | hecho `#26A269` · alta `#E5A50A` · urgente `#E01B24` |
| Fondo claro | `#F0F1F3` · superficie blanca |
| Fondo oscuro | `#17181C` · superficie `#1E2025` |
| Texto | `#17181C` / `#E3E5E9` (dark) |
| Tipografía | Inter + JetBrains Mono (IDs, atajos) |
| Radios | 8–12px · transiciones 150ms |
| Detalle clave | atajos de teclado visibles (kbd chips) |
| Tono | Minimalista y veloz — densidad alta, ruido cero, "pro". |

## 08 · NestHunt — Inmobiliaria

| Token | Valor |
|---|---|
| Primario | `#E07856` (coral suave) · hover `#D96850` |
| Secundario | `#73876D` (salvia) |
| Fondo | `#FCFAF7` (arena) · superficie blanca |
| Texto | `#33302B` · secundario `#7E776D` |
| Bordes | `#EAE2D6` |
| Tipografía | Plus Jakarta Sans (única, redondeada y amable) |
| Radios | cards 24px · pills para precios/filtros |
| Sombras | medias en hover (`shadow-lg`), cálidas |
| Tono | Cálido y aspiracional — fotografía grande, confiable, hogareño. |

## 09 · LearnLoop — Plataforma educativa

| Token | Valor |
|---|---|
| Primario | `#3BA55C` (verde aprendizaje) |
| Acento cálido | `#F5A623` (rachas/logros) · gamificación `#9C5FD4` (XP) |
| Fondo | `#FAFCFA` · superficie blanca |
| Texto | `#26342B` · secundario `#52645A` |
| Tipografía | Nunito (única — redondeada, motivadora) |
| Radios | 24px (muy redondeado, amistoso) |
| Microinteracción | confetti CSS al completar · barras de progreso animadas |
| Tono | Amigable y motivador — gamificación sutil, nunca infantil. |

## 10 · ChatSphere — Mensajería

| Token | Valor |
|---|---|
| Acento | `#7C6CF0` (púrpura eléctrico) |
| Presencia | activo `#3BC97A` · ausente `#E0A93C` |
| Fondo | `#101014` · columnas `#16161C` / mensajes `#1C1D24` |
| Texto | `#E2E4EA` · secundario `#8E93A3` |
| Tipografía | Inter compacta (14px base en chat) |
| Radios | 12px · avatares cuadrados redondeados (8px) |
| Microinteracción | typing dots, hover revela acciones, fade-in de mensajes |
| Tono | Enfocado y cómodo para horas de uso — oscuro por defecto. |

## 11 · DocuMind — Asistente IA

| Token | Valor |
|---|---|
| Acento IA | gradiente `#4C6EF5 → #7048E8` (solo en elementos de IA) |
| Primario UI | `#3B5BDB` |
| Cita resaltada | `#FFF3C4` (amarillo marcador) |
| Fondo | `#F7F8FA` · documento blanco |
| Texto | `#1A1D26` · secundario `#646B7E` |
| Tipografía | Inter (UI) + Source Serif 4 (contenido del documento) |
| Radios | 16px · burbujas de chat 16px |
| Microinteracción | typing caret, cita→scroll al hover |
| Tono | IA confiable y sobria — el gradiente se usa con cuentagotas. |

## 12 · SensorScope — Monitoreo IoT

| Token | Valor |
|---|---|
| Estados | OK `#2ED573` · WARN `#F0B232` · CRIT `#FF4757` (con fondos `#0D2B1A`/`#33260B`/`#36121A`) |
| Fondo | `#0A0E12` (sala de control) · card `#0E141A` |
| Texto | `#D2DDE7` · secundario `#6E8499` |
| Tipografía | IBM Plex Sans + IBM Plex Mono (todas las lecturas) |
| Radios | 12px |
| Microinteracción | pulso en dato vivo · parpadeo suave solo en CRIT |
| Tono | Sala de control técnica — denso, legible, el color ES el estado. |

## 13 · TastyTable — Reservas de restaurantes

| Token | Valor |
|---|---|
| Primario | `#C25E3F` (terracota) |
| Secundario | `#6E2B35` (borgoña) |
| Disponibilidad | `#4F8A5B` |
| Fondo | `#FBF6EE` (crema) |
| Texto | `#3A2C24` · secundario `#6B5A4E` |
| Display | Lora (serif — nombres de restaurantes) |
| Body | Outfit (UI) |
| Radios | cards 24px · botones pill · ticket con perforación |
| Tono | Apetitoso y elegante — cálido, da hambre y confianza. |

## 14 · CryptoVault — Mercados cripto

| Token | Valor |
|---|---|
| Sube / baja | `#16C784` / `#EA3943` (precisos, estilo CMC) |
| Acento neón | `#5EEAD4` (solo CTAs y marca) |
| Fondo | `#08090C` (negro) · superficie `#0D0F14` |
| Texto | `#D2D6E0` · secundario `#697288` |
| Tipografía | Inter (UI) + IBM Plex Mono (todos los precios, tabular) |
| Radios | 12px |
| Microinteracción | flash verde/rojo en cambio de precio |
| Tono | Terminal pro-trader — denso, rápido, oscuro absoluto. |

---

### Convenciones compartidas (las 14)
- Toggle EN/ES en el header de cada mockup (persistido en `localStorage`).
- Escala 4/8px, contraste AA, targets táctiles ≥44px.
- Iconos: Lucide CDN. Fuentes: Google Fonts. CSS: Tailwind CDN.
- Imágenes: placeholders con gradiente + etiqueta `monospace` describiendo la foto real a colocar.
